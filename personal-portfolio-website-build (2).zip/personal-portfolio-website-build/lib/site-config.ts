/**
 * Edit this file to replace all site content with your own.
 * Leave a contact value as an empty string ("") to hide it everywhere.
 */

export const siteConfig = {
  name: "Cheska",
  fullName: "Cheska",
  title: "Virtual Assistant & Creative Support",
  logo: { text: "cheska", accent: "va" },
  url: "https://example.com",
  description:
    "Helping solo business owners and creatives stay organized and show up online through social media management, graphic design, and video & photo editing.",

  bookingUrl: "https://calendly.com/cheskanora-va/30min",

  contact: {
    email: "",
    linkedin: "",
    instagram: "",
    whatsapp: "",
  },

  hero: {
    headlineDark: "Content that gets attention.",
    headlineAccent: "Support that gives it purpose.",
    subheadline:
      "Helping busy business owners and creatives stay organized, stay consistent, and grow through social media management, graphic design, and video & photo editing.",
    image: "/images/portrait.png",
    imageAlt: "Portrait of Cheska",
  },

  services: {
    eyebrow: "What I Do",
    title: "Services Designed For Growth",
    description:
      "Practical creative support that keeps your brand consistent and frees up your time to focus on the work you love.",
    items: [
      {
        icon: "calendar",
        title: "Social Media Management",
        description:
          "Planning, creating, scheduling, and managing content with purpose — from content calendars and captions to community engagement — so your brand shows up consistently.",
      },
      {
        icon: "palette",
        title: "Graphic Design",
        description:
          "Branded graphics, carousels, look books, e-books, and promotional creatives designed to communicate your message clearly and match your brand aesthetic.",
      },
      {
        icon: "film",
        title: "Video & Photo Editing",
        description:
          "Engaging short-form video, photo retouching, and content visuals that support your social media strategy and brand identity.",
      },
    ],
  },

  portfolio: {
    eyebrow: "Selected Projects",
    title: "A Portfolio of Creative Directions.",
    description:
      "A collection of sample creative projects. Replace these with your own work in lib/site-config.ts.",
    categories: [
      {
        id: "graphic-design",
        title: "Graphic Design",
        description:
          "Social media graphics and marketing creatives built to strengthen brand identity and stop the scroll.",
        highlightsLabel: "Design Highlights",
        highlights: ["Modern Visuals", "Marketing Focused", "Brand Consistency", "On-Brand Aesthetics"],
        groups: [
          {
            title: "Social Media Concepts",
            description:
              "Sample concept posts across different niches — skincare, cafe, wellness, and digital product launches.",
            aspect: "portrait" as const,
            items: [
              { src: "/images/work/design-1.png", alt: "Skincare brand Instagram post concept" },
              { src: "/images/work/design-2.png", alt: "Cafe seasonal menu Instagram post concept" },
              { src: "/images/work/design-3.png", alt: "Wellness studio Instagram post concept" },
              { src: "/images/work/design-4.png", alt: "E-book launch carousel cover concept" },
            ],
          },
        ],
      },
      {
        id: "video-photo",
        title: "Video & Photo Editing",
        description:
          "Short-form videos and polished photo edits built to capture attention and keep visuals on-brand.",
        highlightsLabel: "Creative Highlights",
        highlights: ["Short-Form Content", "Social Media Ready", "Color Corrected", "High Resolution"],
        groups: [
          {
            title: "Edited Samples",
            description:
              "Add a videoUrl to any item to play a video in the lightbox instead of an image.",
            aspect: "portrait" as const,
            items: [
              {
                src: "/images/work/video-1.png",
                alt: "Behind-the-scenes short-form video sample",
                videoUrl: "",
                label: "Short-form video",
              },
              {
                src: "/images/work/photo-1.png",
                alt: "Retouched look book flat lay photo",
                label: "Photo retouching",
              },
            ],
          },
        ],
      },
    ],
  },

  about: {
    eyebrow: "About",
    title: "A Little About Me",
    image: "/images/portrait.png",
    imageAlt: "Portrait of Cheska",
    paragraphs: [
      "Hi, I’m Cheska — a virtual assistant and creative support partner for solo business owners and creatives. I love helping brands stay organized, consistent, and visually polished online.",
      "From social media calendars and branded graphics to look books, e-books, and edited visuals, I take the time to understand your business and your brand style so the work feels like you.",
      "I approach every project with attention to detail, clear communication, and a focus on helping you plan ahead with confidence.",
    ],
  },

  whyMe: {
    eyebrow: "My Approach",
    title: "Why Work With Me?",
    items: [
      {
        icon: "target",
        title: "I Learn Your Brand First",
        description:
          "I take time to understand your business, goals, audience, and brand aesthetic — then turn that into content that feels authentic to you.",
      },
      {
        icon: "list",
        title: "Organized & Proactive",
        description:
          "Clear notes, clear timelines, and questions when something needs clarity — so you always know where your projects stand.",
      },
      {
        icon: "handshake",
        title: "A True Partnership",
        description:
          "I work as an extension of your team, with patience and care, so you can focus on growing your business.",
      },
    ],
  },

  testimonials: {
    eyebrow: "Social Proof",
    title: "Trusted By The People I Work With.",
    description:
      "Great work goes beyond deliverables — it’s about trust, clear communication, and being a reliable partner.",
    items: [
      {
        quote:
          "Having Cheska as part of my team has been very relieving for me as a solo business owner and creative. She is knowledgeable about my industry and my business, and offers clear, accurate, professional admin support. She takes great notes, asks for clarity when needed, and really knows my brand style and aesthetics. In just one month, Cheska helped me with an amazing social media content calendar, assisted with client tasks, created a beautiful look book project, and even helped me finish an e-book! I’m very grateful for all she does with so much patience and kindness.",
        name: "Tiara Trotter",
        role: "CEO, Geeky Mamas Studios",
        location: "Maui, Hawaii",
      },
    ],
  },

  faq: {
    eyebrow: "Got Questions?",
    title: "A Few Things Clients Usually Ask.",
    description:
      "If something else is on your mind, it’s faster to just ask — send a message below or book a free discovery call.",
    items: [
      {
        q: "Can you work with any type of business?",
        a: "I’m open to different industries. What matters most is understanding your business, audience, and goals.",
      },
      {
        q: "Do you offer your services in packages?",
        a: "Yes — services can be bundled depending on what your business needs. We’ll figure out the right fit together on a discovery call.",
      },
      {
        q: "How do we get started?",
        a: "Book a free discovery call or send a message. We’ll talk about your business, what you want to improve, and whether I’m the right person to help.",
      },
      {
        q: "What happens after I book a call?",
        a: "We’ll have a relaxed conversation about your goals. Afterward, I’ll share a tailored recommendation so you know exactly what to expect — no pressure.",
      },
    ],
  },

  contactSection: {
    eyebrow: "Let’s Connect",
    title: "Ready To Elevate Your Online Presence?",
    description:
      "Whether you need consistent social media, on-brand graphics, or polished edits, I’d love to hear about your business and explore how we can work together.",
  },

  cta: {
    title: "Let’s Build Something Meaningful Together.",
  },

  footer: {
    tagline:
      "Creative and admin support that helps solo business owners stay organized, consistent, and confident online.",
  },
}

export const navLinks = [
  { href: "#home", label: "Home" },
  { href: "#services", label: "Services" },
  { href: "#portfolio", label: "Portfolio" },
  { href: "#about", label: "About" },
  { href: "#contact", label: "Contact" },
]

export type SiteConfig = typeof siteConfig
