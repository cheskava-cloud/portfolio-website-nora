import { About } from "@/components/site/about"
import { Contact } from "@/components/site/contact"
import { Faq } from "@/components/site/faq"
import { FloatingCta } from "@/components/site/floating-cta"
import { Footer } from "@/components/site/footer"
import { Header } from "@/components/site/header"
import { Hero } from "@/components/site/hero"
import { Portfolio } from "@/components/site/portfolio"
import { Services } from "@/components/site/services"
import { Testimonials } from "@/components/site/testimonials"
import { WhyMe } from "@/components/site/why-me"

export default function Home() {
  return (
    <>
      <Header />
      <main id="main">
        <Hero />
        <Services />
        <Portfolio />
        <About />
        <WhyMe />
        <Testimonials />
        <Faq />
        <Contact />
      </main>
      <Footer />
      <FloatingCta />
    </>
  )
}
