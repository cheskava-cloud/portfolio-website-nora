import { siteConfig } from "@/lib/site-config"
import { FeatureIcon } from "./icon"
import { Container, SectionHeading } from "./primitives"
import { Reveal } from "./reveal"

export function WhyMe() {
  const { whyMe } = siteConfig
  return (
    <section aria-labelledby="why-heading" className="bg-sky py-20 lg:py-28">
      <Container className="flex flex-col gap-14">
        <div id="why-heading">
          <SectionHeading eyebrow={whyMe.eyebrow} title={whyMe.title} />
        </div>
        <ul className="mx-auto grid w-full max-w-5xl gap-5 md:grid-cols-3">
          {whyMe.items.map((item, i) => (
            <Reveal as="li" key={item.title} delay={i * 100}>
              <article className="flex h-full flex-col gap-4 rounded-3xl bg-navy p-6 text-white transition-transform duration-300 hover:-translate-y-1">
                <FeatureIcon name={item.icon} />
                <h3 className="pt-1 text-lg font-bold">{item.title}</h3>
                <p className="text-sm leading-loose text-white/75">{item.description}</p>
              </article>
            </Reveal>
          ))}
        </ul>
      </Container>
    </section>
  )
}
