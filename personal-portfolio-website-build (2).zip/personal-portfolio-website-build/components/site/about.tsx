import Image from "next/image"
import { siteConfig } from "@/lib/site-config"
import { ButtonLink, Container, SectionHeading } from "./primitives"
import { Reveal } from "./reveal"

export function About() {
  const { about } = siteConfig
  return (
    <section id="about" className="bg-white py-20 lg:py-28">
      <Container className="flex flex-col gap-14">
        <SectionHeading eyebrow={about.eyebrow} title={about.title} />
        <div className="grid items-center gap-10 lg:grid-cols-[0.8fr_1.7fr] lg:gap-16">
          <Reveal className="mx-auto w-full max-w-sm">
            <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem] border-4 border-white shadow-[0_25px_60px_-20px_rgb(15_23_42/0.35)]">
              <Image src={about.image || "/placeholder.svg"} alt={about.imageAlt} fill sizes="(min-width: 1024px) 30vw, 90vw" className="object-cover" />
            </div>
          </Reveal>
          <Reveal delay={120} className="flex flex-col gap-5">
            {about.paragraphs.map((p) => (
              <p key={p.slice(0, 24)} className="text-pretty text-base leading-loose text-muted-foreground sm:text-lg">
                {p}
              </p>
            ))}
            <div className="pt-2">
              <ButtonLink href="#contact">{"Let's Work Together"}</ButtonLink>
            </div>
          </Reveal>
        </div>
      </Container>
    </section>
  )
}
