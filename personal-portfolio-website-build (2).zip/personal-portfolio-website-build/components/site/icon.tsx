import {
  CalendarDays,
  Clapperboard,
  Handshake,
  ListChecks,
  Palette,
  Sparkles,
  Target,
  type LucideIcon,
} from "lucide-react"

const icons: Record<string, LucideIcon> = {
  calendar: CalendarDays,
  palette: Palette,
  film: Clapperboard,
  target: Target,
  list: ListChecks,
  handshake: Handshake,
}

export function FeatureIcon({ name }: { name: string }) {
  const Icon = icons[name] ?? Sparkles
  return (
    <span className="inline-flex size-11 items-center justify-center rounded-xl bg-white/10 text-brand-light">
      <Icon className="size-5" aria-hidden />
    </span>
  )
}
