import { BriefcaseBusiness as Linkedin, CalendarCheck, Camera as Instagram, Mail, MessageCircle } from "lucide-react"
import { siteConfig } from "@/lib/site-config"
import { Logo } from "./logo"
import { Container } from "./primitives"

export function getContactLinks() {
  const { contact, bookingUrl } = siteConfig
  return [
    { label: "Email", href: contact.email ? `mailto:${contact.email}` : "", icon: Mail },
    { label: "LinkedIn", href: contact.linkedin, icon: Linkedin },
    { label: "Instagram", href: contact.instagram, icon: Instagram },
    { label: "Calendly", href: bookingUrl, icon: CalendarCheck },
    { label: "WhatsApp", href: contact.whatsapp, icon: MessageCircle },
  ].filter((l) => l.href)
}

export function Footer() {
  const links = getContactLinks()
  const year = new Date().getFullYear()

  return (
    <footer className="bg-navy pt-16 text-white">
      <Container className="grid gap-12 pb-12 md:grid-cols-[1.5fr_1fr_1fr]">
        <div className="flex flex-col gap-5">
          <Logo inverted />
          <p className="max-w-md text-sm leading-relaxed text-white/75">{siteConfig.footer.tagline}</p>
          <p className="text-xs font-bold uppercase tracking-[0.15em]">{"Let's stay connected!"}</p>
          <ul className="flex gap-3">
            {links.map(({ label, href, icon: Icon }) => (
              <li key={label}>
                <a
                  href={href}
                  target={href.startsWith("mailto:") ? undefined : "_blank"}
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="flex size-10 items-center justify-center rounded-full bg-white text-brand transition-transform hover:-translate-y-0.5"
                >
                  <Icon className="size-4" aria-hidden />
                </a>
              </li>
            ))}
          </ul>
        </div>

        <nav aria-label="Services">
          <h2 className="font-sans text-sm font-bold">Services</h2>
          <ul className="mt-4 flex flex-col gap-3">
            {siteConfig.services.items.map((s) => (
              <li key={s.title}>
                <a href="#services" className="text-sm text-white/75 transition-colors hover:text-white">
                  {s.title}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="Contact">
          <h2 className="font-sans text-sm font-bold">Contact</h2>
          <ul className="mt-4 flex flex-col gap-3">
            {links.map(({ label, href }) => (
              <li key={label}>
                <a
                  href={href}
                  target={href.startsWith("mailto:") ? undefined : "_blank"}
                  rel="noopener noreferrer"
                  className="text-sm text-white/75 transition-colors hover:text-white"
                >
                  {label}
                </a>
              </li>
            ))}
            <li>
              <a href="#contact" className="text-sm text-white/75 transition-colors hover:text-white">
                Send a message
              </a>
            </li>
          </ul>
        </nav>
      </Container>
      <Container className="flex flex-col gap-2 border-t border-white/10 py-6 text-xs text-white/60 sm:flex-row sm:justify-between">
        <p>
          © {year} {siteConfig.fullName}. All Rights Reserved.
        </p>
        <a href="#home" className="hover:text-white">
          Back to top
        </a>
      </Container>
    </footer>
  )
}
