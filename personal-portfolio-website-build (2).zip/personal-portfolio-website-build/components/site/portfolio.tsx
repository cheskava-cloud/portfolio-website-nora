"use client"

import { ChevronLeft, ChevronRight, Expand, Play, X } from "lucide-react"
import Image from "next/image"
import { useCallback, useEffect, useRef, useState } from "react"
import { siteConfig } from "@/lib/site-config"
import { cn } from "@/lib/utils"
import { Container, Eyebrow, SectionHeading } from "./primitives"
import { Reveal } from "./reveal"

type WorkItem = { src: string; alt: string; videoUrl?: string; label?: string }

export function Portfolio() {
  const { portfolio } = siteConfig
  const [activeTab, setActiveTab] = useState(portfolio.categories[0].id)
  const [lightbox, setLightbox] = useState<{ items: WorkItem[]; index: number } | null>(null)

  const category = portfolio.categories.find((c) => c.id === activeTab) ?? portfolio.categories[0]

  return (
    <section id="portfolio" className="bg-sky py-20 lg:py-28">
      <Container className="flex flex-col gap-12">
        <SectionHeading eyebrow={portfolio.eyebrow} title={portfolio.title} description={portfolio.description} />

        <Reveal>
          <div role="tablist" aria-label="Portfolio categories" className="mx-auto flex flex-wrap justify-center gap-2 rounded-full bg-white p-1.5 shadow-sm">
            {portfolio.categories.map((c) => (
              <button
                key={c.id}
                role="tab"
                id={`tab-${c.id}`}
                aria-selected={activeTab === c.id}
                aria-controls={`panel-${c.id}`}
                onClick={() => setActiveTab(c.id)}
                className={cn(
                  "rounded-full px-5 py-2.5 text-sm font-bold transition-all sm:text-base",
                  activeTab === c.id ? "btn-primary text-white" : "text-foreground hover:text-brand",
                )}
              >
                {c.title}
              </button>
            ))}
          </div>
        </Reveal>

        <div
          key={category.id}
          role="tabpanel"
          id={`panel-${category.id}`}
          aria-labelledby={`tab-${category.id}`}
          className="animate-in fade-in slide-in-from-bottom-4 overflow-hidden rounded-[2rem] bg-navy text-white shadow-2xl shadow-navy/20 duration-500"
        >
          <div className="border-b border-white/10 px-6 py-8 sm:px-10">
            <h3 className="text-lg font-bold">{category.title}</h3>
            <p className="mt-2 text-pretty text-base leading-relaxed text-white/75 sm:text-lg">{category.description}</p>
          </div>

          {category.groups.map((group) => (
            <div key={group.title} className="flex flex-col gap-6 px-4 py-8 sm:px-6">
              <div className="mx-auto max-w-2xl text-center">
                <h4 className="text-lg font-bold">{group.title}</h4>
                <p className="mt-1 text-sm leading-relaxed text-white/70">{group.description}</p>
              </div>
              <ul className={cn("grid gap-4 sm:gap-5", group.items.length >= 4 ? "grid-cols-2 lg:grid-cols-4" : "grid-cols-1 sm:grid-cols-2 lg:mx-auto lg:w-2/3")}>
                {group.items.map((item: WorkItem, index: number) => (
                  <li key={item.src}>
                    <button
                      type="button"
                      onClick={() => setLightbox({ items: group.items, index })}
                      className="group relative block aspect-[4/5] w-full overflow-hidden rounded-2xl bg-white/5 ring-1 ring-white/10 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-light"
                    >
                      <Image
                        src={item.src || "/placeholder.svg"}
                        alt={item.alt}
                        fill
                        sizes="(min-width: 1024px) 25vw, 50vw"
                        className="object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <span className="absolute inset-0 flex items-center justify-center bg-navy/0 transition-colors duration-300 group-hover:bg-navy/40">
                        <span className="flex size-12 scale-75 items-center justify-center rounded-full bg-white text-brand opacity-0 transition-all duration-300 group-hover:scale-100 group-hover:opacity-100">
                          {item.videoUrl ? <Play className="size-5" aria-hidden /> : <Expand className="size-5" aria-hidden />}
                        </span>
                      </span>
                      {item.label && (
                        <span className="absolute bottom-3 left-3 rounded-full bg-navy/80 px-3 py-1 text-xs font-semibold backdrop-blur">
                          {item.label}
                        </span>
                      )}
                      <span className="sr-only">Open {item.alt} in viewer</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div className="border-t border-white/10 px-6 py-8 sm:px-10">
            <Eyebrow className="text-brand-light">{category.highlightsLabel}</Eyebrow>
            <ul className="mt-4 flex flex-wrap gap-3">
              {category.highlights.map((h) => (
                <li key={h} className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-sm font-semibold">
                  {h}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Container>

      <Lightbox state={lightbox} onChange={setLightbox} />
    </section>
  )
}

function Lightbox({
  state,
  onChange,
}: {
  state: { items: WorkItem[]; index: number } | null
  onChange: (s: { items: WorkItem[]; index: number } | null) => void
}) {
  const dialogRef = useRef<HTMLDialogElement>(null)

  useEffect(() => {
    const dialog = dialogRef.current
    if (!dialog) return
    if (state && !dialog.open) dialog.showModal()
    if (!state && dialog.open) dialog.close()
  }, [state])

  const step = useCallback(
    (dir: number) => {
      if (!state) return
      const len = state.items.length
      onChange({ ...state, index: (state.index + dir + len) % len })
    },
    [state, onChange],
  )

  useEffect(() => {
    if (!state) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") step(1)
      if (e.key === "ArrowLeft") step(-1)
    }
    document.addEventListener("keydown", onKey)
    return () => document.removeEventListener("keydown", onKey)
  }, [state, step])

  const item = state?.items[state.index]

  return (
    <dialog
      ref={dialogRef}
      onClose={() => onChange(null)}
      onClick={(e) => e.target === e.currentTarget && onChange(null)}
      aria-label={item?.alt ?? "Portfolio viewer"}
      className="m-auto max-h-[92svh] w-[min(92vw,900px)] overflow-visible bg-transparent p-0 backdrop:bg-navy/85 backdrop:backdrop-blur-sm"
    >
      {item && state && (
        <div className="relative flex flex-col items-center gap-4">
          <div className="relative h-[78svh] w-full">
            {item.videoUrl ? (
              <video src={item.videoUrl} controls autoPlay playsInline className="size-full rounded-2xl object-contain" />
            ) : (
              <Image src={item.src || "/placeholder.svg"} alt={item.alt} fill sizes="92vw" className="rounded-2xl object-contain" />
            )}
          </div>
          <p className="text-center text-sm text-white/85">
            {item.alt} · {state.index + 1} / {state.items.length}
          </p>
          <button
            type="button"
            onClick={() => onChange(null)}
            aria-label="Close viewer"
            autoFocus
            className="absolute -top-2 right-0 flex size-11 items-center justify-center rounded-full bg-white text-navy shadow-lg lg:-right-14 lg:top-0"
          >
            <X className="size-5" aria-hidden />
          </button>
          {state.items.length > 1 && (
            <>
              <button
                type="button"
                onClick={() => step(-1)}
                aria-label="Previous image"
                className="absolute left-2 top-[39svh] flex size-11 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 text-navy shadow-lg lg:-left-16"
              >
                <ChevronLeft className="size-5" aria-hidden />
              </button>
              <button
                type="button"
                onClick={() => step(1)}
                aria-label="Next image"
                className="absolute right-2 top-[39svh] flex size-11 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 text-navy shadow-lg lg:-right-16"
              >
                <ChevronRight className="size-5" aria-hidden />
              </button>
            </>
          )}
        </div>
      )}
    </dialog>
  )
}
