import Link from "next/link"
import type { ComponentProps, ReactNode } from "react"
import { cn } from "@/lib/utils"
import { Reveal } from "./reveal"

export function Container({ className, ...props }: ComponentProps<"div">) {
  return <div className={cn("mx-auto w-full max-w-7xl px-5 sm:px-8 lg:px-20", className)} {...props} />
}

export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <p className={cn("text-xs font-bold uppercase tracking-[0.18em] text-brand", className)}>{children}</p>
  )
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "center",
}: {
  eyebrow: string
  title: string
  description?: string
  align?: "center" | "left"
}) {
  return (
    <Reveal className={cn("flex flex-col gap-4", align === "center" && "mx-auto max-w-3xl items-center text-center")}>
      <Eyebrow>{eyebrow}</Eyebrow>
      <h2 className="text-balance text-4xl font-extrabold leading-[1.05] tracking-[-0.04em] text-foreground sm:text-5xl lg:text-6xl">
        {title}
      </h2>
      {description && (
        <p className="max-w-2xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
          {description}
        </p>
      )}
    </Reveal>
  )
}

type ButtonVariant = "primary" | "outline" | "dark" | "white" | "ghost-white"

const variants: Record<ButtonVariant, string> = {
  primary: "btn-primary text-white hover:brightness-110",
  outline: "border border-border bg-white text-brand hover:border-brand/40 hover:bg-sky-soft",
  dark: "bg-navy text-white hover:bg-navy/90",
  white: "bg-white text-brand hover:bg-sky",
  "ghost-white": "border border-white/40 text-white hover:bg-white/10",
}

export function ButtonLink({
  href,
  children,
  variant = "primary",
  className,
  external,
}: {
  href: string
  children: ReactNode
  variant?: ButtonVariant
  className?: string
  external?: boolean
}) {
  const classes = cn(
    "inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-base font-bold transition-all duration-300 hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand",
    variants[variant],
    className,
  )
  if (external) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className={classes}>
        {children}
        <span className="sr-only"> (opens in a new tab)</span>
      </a>
    )
  }
  return (
    <Link href={href} className={classes}>
      {children}
    </Link>
  )
}
