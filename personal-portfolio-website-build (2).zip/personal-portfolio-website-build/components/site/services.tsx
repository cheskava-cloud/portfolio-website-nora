import { siteConfig } from "@/lib/site-config"
import { FeatureIcon } from "./icon"
import { ButtonLink, Container, SectionHeading } from "./primitives"
import { Reveal } from "./reveal"

export function Services() {
  const { services } = siteConfig
  return (
    <section id="services" className="bg-white py-20 lg:py-28">
      <Container className="grid gap-12 lg:grid-cols-[1fr_1.15fr] lg:gap-16">
        <div className="flex flex-col gap-8 lg:sticky lg:top-36 lg:self-start">
          <SectionHeading
            align="left"
            eyebrow={services.eyebrow}
            title={services.title}
            description={services.description}
          />
          <Reveal delay={100}>
            <ButtonLink href="#portfolio" variant="dark" className="px-8">
              Explore My Work
            </ButtonLink>
          </Reveal>
        </div>

        <ul className="grid gap-5 sm:grid-cols-2">
          {services.items.map((service, i) => (
            <Reveal
              as="li"
              key={service.title}
              delay={i * 100}
              className={i === services.items.length - 1 && services.items.length % 2 === 1 ? "sm:col-span-2" : ""}
            >
              <article className="group flex h-full flex-col gap-5 rounded-3xl bg-navy p-6 text-white transition-transform duration-300 hover:-translate-y-1 sm:p-7">
                <FeatureIcon name={service.icon} />
                <h3 className="text-lg font-bold">{service.title}</h3>
                <p className="leading-loose text-white/75">{service.description}</p>
              </article>
            </Reveal>
          ))}
        </ul>
      </Container>
    </section>
  )
}
