import Link from "next/link"
import { siteConfig } from "@/lib/site-config"
import { cn } from "@/lib/utils"

export function Logo({ inverted = false, className }: { inverted?: boolean; className?: string }) {
  const { text, accent } = siteConfig.logo
  return (
    <Link
      href="#home"
      aria-label={`${siteConfig.fullName} — back to top`}
      className={cn(
        "font-heading text-3xl font-extrabold tracking-[-0.04em]",
        inverted ? "text-white" : "text-foreground",
        className,
      )}
    >
      {text}
      <span className="text-brand">.</span>
      {accent}
      <span className={inverted ? "text-white" : "text-foreground"}>.</span>
    </Link>
  )
}
