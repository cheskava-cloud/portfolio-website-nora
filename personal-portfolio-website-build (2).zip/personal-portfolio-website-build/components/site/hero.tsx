import Image from "next/image"
import { siteConfig } from "@/lib/site-config"
import { ButtonLink, Container } from "./primitives"

export function Hero() {
  const { hero, bookingUrl } = siteConfig
  return (
    <section id="home" className="relative overflow-hidden bg-white">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-40 top-1/4 size-[720px] rounded-full bg-[radial-gradient(circle,rgb(47_128_228/0.55)_0%,rgb(47_128_228/0.15)_45%,transparent_70%)] blur-2xl"
      />
      <Container className="relative grid items-center gap-10 pb-0 pt-14 lg:min-h-[calc(100svh-7rem)] lg:grid-cols-[1.35fr_1fr] lg:pt-0">
        <div className="flex flex-col gap-6 py-6 lg:py-24">
          <h1 className="animate-in fade-in slide-in-from-bottom-6 text-balance text-5xl font-extrabold leading-[1.08] tracking-[-0.04em] duration-700 sm:text-6xl lg:text-[76px]">
            <span className="text-foreground">{hero.headlineDark}</span>{" "}
            <span className="text-brand">{hero.headlineAccent}</span>
          </h1>
          <p className="animate-in fade-in slide-in-from-bottom-4 max-w-xl fill-mode-both text-pretty text-base leading-relaxed text-muted-foreground delay-150 duration-700 sm:text-lg">
            {hero.subheadline}
          </p>
          <div className="animate-in fade-in slide-in-from-bottom-4 flex flex-wrap gap-4 pt-2 fill-mode-both delay-300 duration-700">
            <ButtonLink href={bookingUrl} external>
              Book Your Free Discovery Call
            </ButtonLink>
            <ButtonLink href="#contact" variant="outline">
              {"Let's Connect"}
            </ButtonLink>
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-md self-end animate-in fade-in zoom-in-95 duration-1000 lg:max-w-none">
          <div className="relative aspect-[4/5] w-full [mask-image:linear-gradient(to_bottom,black_70%,transparent)]">
            <Image
              src={hero.image || "/placeholder.svg"}
              alt={hero.imageAlt}
              fill
              priority
              sizes="(min-width: 1024px) 40vw, 90vw"
              className="rounded-t-[2.5rem] object-cover object-top"
            />
          </div>
        </div>
      </Container>
    </section>
  )
}
