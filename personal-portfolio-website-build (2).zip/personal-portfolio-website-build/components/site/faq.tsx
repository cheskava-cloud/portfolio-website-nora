"use client"

import { Plus } from "lucide-react"
import { useId, useState } from "react"
import { siteConfig } from "@/lib/site-config"
import { cn } from "@/lib/utils"
import { Container, SectionHeading } from "./primitives"
import { Reveal } from "./reveal"

export function Faq() {
  const { faq } = siteConfig
  const [open, setOpen] = useState<number | null>(null)
  const baseId = useId()

  return (
    <section id="faq" className="bg-white py-20 lg:py-28">
      <Container className="flex flex-col gap-14">
        <SectionHeading eyebrow={faq.eyebrow} title={faq.title} description={faq.description} />
        <Reveal className="mx-auto flex w-full max-w-3xl flex-col gap-4">
          {faq.items.map((item, i) => {
            const isOpen = open === i
            return (
              <div key={item.q} className={cn("rounded-2xl border bg-white transition-colors", isOpen ? "border-brand/40 shadow-sm" : "border-border")}>
                <h3>
                  <button
                    type="button"
                    id={`${baseId}-q${i}`}
                    aria-expanded={isOpen}
                    aria-controls={`${baseId}-a${i}`}
                    onClick={() => setOpen(isOpen ? null : i)}
                    className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left font-sans text-base font-bold text-foreground"
                  >
                    {item.q}
                    <Plus className={cn("size-5 shrink-0 text-brand transition-transform duration-300", isOpen && "rotate-45")} aria-hidden />
                  </button>
                </h3>
                <div
                  id={`${baseId}-a${i}`}
                  role="region"
                  aria-labelledby={`${baseId}-q${i}`}
                  className={cn("grid transition-all duration-300", isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0")}
                >
                  <div className="overflow-hidden">
                    <p className="px-6 pb-6 leading-relaxed text-muted-foreground">{item.a}</p>
                  </div>
                </div>
              </div>
            )
          })}
        </Reveal>
      </Container>
    </section>
  )
}
