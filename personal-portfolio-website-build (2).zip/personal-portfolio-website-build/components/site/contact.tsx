"use client"

import { CheckCircle2 } from "lucide-react"
import { useState, type FormEvent } from "react"
import { siteConfig } from "@/lib/site-config"
import { ButtonLink, Container, SectionHeading } from "./primitives"
import { Reveal } from "./reveal"

const inputClass =
  "w-full rounded-xl border border-input bg-white px-5 py-4 text-base text-foreground placeholder:text-muted-foreground transition-colors focus:border-brand focus:outline-none focus:ring-4 focus:ring-brand/15"

export function Contact() {
  const { contactSection, contact, bookingUrl, cta } = siteConfig
  const [status, setStatus] = useState<"idle" | "sent" | "no-email">("idle")

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const data = new FormData(e.currentTarget)
    if (!contact.email) {
      setStatus("no-email")
      return
    }
    const name = `${data.get("firstName")} ${data.get("lastName")}`.trim()
    const body = `${data.get("message")}\n\nName: ${name}\nEmail: ${data.get("email")}\nPhone: ${data.get("phone") || "-"}`
    window.location.href = `mailto:${contact.email}?subject=${encodeURIComponent(`New inquiry from ${name}`)}&body=${encodeURIComponent(body)}`
    setStatus("sent")
  }

  return (
    <section id="contact" className="bg-sky-soft py-20 lg:py-28">
      <Container className="flex flex-col gap-14">
        <SectionHeading eyebrow={contactSection.eyebrow} title={contactSection.title} description={contactSection.description} />

        <Reveal>
          <form
            id="inquiry-form"
            onSubmit={handleSubmit}
            className="grid gap-5 rounded-[2rem] bg-white p-6 shadow-[0_25px_60px_-30px_rgb(15_23_42/0.25)] sm:grid-cols-2 sm:p-12"
          >
            <label className="flex flex-col gap-2">
              <span className="sr-only">First name</span>
              <input name="firstName" required autoComplete="given-name" placeholder="First Name *" className={inputClass} />
            </label>
            <label className="flex flex-col gap-2">
              <span className="sr-only">Last name</span>
              <input name="lastName" required autoComplete="family-name" placeholder="Last Name *" className={inputClass} />
            </label>
            <label className="flex flex-col gap-2">
              <span className="sr-only">Email address</span>
              <input name="email" type="email" required autoComplete="email" placeholder="Email Address *" className={inputClass} />
            </label>
            <label className="flex flex-col gap-2">
              <span className="sr-only">Phone number (optional)</span>
              <input name="phone" type="tel" autoComplete="tel" placeholder="Phone Number (Optional)" className={inputClass} />
            </label>
            <label className="flex flex-col gap-2 sm:col-span-2">
              <span className="sr-only">Tell me about your business</span>
              <textarea name="message" required rows={6} placeholder="Tell me about your business..." className={`${inputClass} resize-y`} />
            </label>
            <div className="flex flex-col gap-4 sm:col-span-2">
              <button type="submit" className="btn-primary w-full rounded-full px-6 py-4 text-base font-bold text-white transition-all hover:-translate-y-0.5 hover:brightness-110">
                Send Message
              </button>
              <p role="status" aria-live="polite" className="text-center text-sm text-muted-foreground">
                {status === "idle" && "Your information stays private and will only be used to respond to your inquiry."}
                {status === "sent" && (
                  <span className="inline-flex items-center gap-2 text-brand">
                    <CheckCircle2 className="size-4" aria-hidden /> Your email app should open with your message ready to send.
                  </span>
                )}
                {status === "no-email" && (
                  <>
                    {"Messages aren't connected yet — please "}
                    <a href={bookingUrl} target="_blank" rel="noopener noreferrer" className="font-bold text-brand underline">
                      book a free discovery call
                    </a>{" "}
                    instead.
                  </>
                )}
              </p>
            </div>
          </form>
        </Reveal>

        <Reveal>
          <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-brand via-[#0d56aa] to-[#063e80] px-6 py-16 text-center text-white sm:px-12 sm:py-20">
            <div aria-hidden className="absolute -left-20 -top-20 size-72 rounded-full bg-white/10 blur-3xl" />
            <h2 className="relative mx-auto max-w-3xl text-balance text-3xl font-extrabold leading-tight tracking-[-0.03em] sm:text-5xl">
              {cta.title}
            </h2>
            <div className="relative mt-8 flex flex-wrap justify-center gap-4">
              <ButtonLink href={bookingUrl} external variant="white" className="px-8 py-4">
                Book Your Free Discovery Call
              </ButtonLink>
              <ButtonLink href="#inquiry-form" variant="ghost-white" className="px-8 py-4">
                Make an Inquiry
              </ButtonLink>
            </div>
          </div>
        </Reveal>
      </Container>
    </section>
  )
}
