import { Quote, Star } from "lucide-react"
import { siteConfig } from "@/lib/site-config"
import { cn } from "@/lib/utils"
import { Container, SectionHeading } from "./primitives"
import { Reveal } from "./reveal"

export function Testimonials() {
  const { testimonials } = siteConfig
  if (testimonials.items.length === 0) return null
  const single = testimonials.items.length === 1

  return (
    <section aria-labelledby="testimonials-heading" className="bg-[radial-gradient(ellipse_at_top_left,var(--sky)_0%,white_55%)] py-20 lg:py-28">
      <Container className="flex flex-col gap-14">
        <div id="testimonials-heading">
          <SectionHeading eyebrow={testimonials.eyebrow} title={testimonials.title} description={testimonials.description} />
        </div>
        <ul className={cn("grid gap-6", single ? "mx-auto max-w-3xl" : "md:grid-cols-2 lg:grid-cols-3")}>
          {testimonials.items.map((t, i) => (
            <Reveal as="li" key={t.name} delay={i * 100}>
              <figure className="relative flex h-full flex-col rounded-[2rem] bg-navy p-8 text-white shadow-2xl shadow-navy/25 sm:p-10">
                <Quote className="absolute right-8 top-8 size-12 rotate-180 fill-white/10 text-transparent" aria-hidden />
                <div className="flex gap-1 text-amber-400" aria-label="5 out of 5 stars">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <Star key={s} className="size-5 fill-current" aria-hidden />
                  ))}
                </div>
                <blockquote className="mt-6 flex-1 text-pretty text-base leading-loose text-white/85">
                  <p>{t.quote}</p>
                </blockquote>
                <figcaption className="mt-8 flex items-center justify-between gap-4 border-t border-white/10 pt-6">
                  <div>
                    <p className="font-bold">{t.name}</p>
                    <p className="mt-1 text-sm text-white/65">{t.role}</p>
                    <p className="mt-1 text-sm font-semibold text-brand-light">{t.location}</p>
                  </div>
                  <span
                    aria-hidden
                    className="flex size-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-brand to-brand-light font-heading text-lg font-bold"
                  >
                    {t.name
                      .split(" ")
                      .map((n) => n[0])
                      .slice(0, 2)
                      .join("")}
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </ul>
      </Container>
    </section>
  )
}
